create definer = root@localhost trigger update_area
    before insert
    on game_status
    for each row
BEGIN
    SET NEW.land_type_1_area = NEW.land_type_1_count * 100;
    SET NEW.land_type_2_area = NEW.land_type_2_count * 100;
    SET NEW.land_type_3_area = NEW.land_type_3_count * 100;
    SET NEW.land_type_4_area = NEW.land_type_4_count * 100;
END;

